﻿Imports System.Net.Mail
Imports System.ComponentModel




Public Class Form1
    Dim Email As System.Threading.Thread
    Dim wclient As New System.Net.WebClient
    Private Sub FormSkin1_Click(sender As Object, e As EventArgs) Handles FormSkin1.Click

    End Sub
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Email = New System.Threading.Thread(AddressOf Email123)
        Email.Start()
    End Sub

    Private Sub FlatButton2_Click(sender As Object, e As EventArgs) Handles FlatButton2.Click
        Timer1.Enabled = False
    End Sub
    Private Sub FlatButton1_Click(sender As Object, e As EventArgs) Handles FlatButton1.Click
        Timer1.Enabled = True

    End Sub
    Private Sub Email123()
        Try
            Dim SmtpServer As New SmtpClient("smtp.gmail.com")
            Dim mail As New MailMessage()
            SmtpServer.Credentials = New System.Net.NetworkCredential("advancedantonsspam@gmail.com", "veryhot123")
            SmtpServer.EnableSsl = True
            SmtpServer.Port = 587
            mail = New MailMessage()
            mail.From = New MailAddress("thisisntaspambot@gmail.com")
            mail.To.Add(FlatTextBox1.Text)
            mail.Subject = (FlatTextBox2.Text)
            mail.Body = (TextBox1.Text)
            SmtpServer.Send(mail)
            FlatLabel6.Text = ("Message Sent To " + FlatTextBox1.Text)

       
        Catch ex As Exception

            FlatLabel6.Text = ("Failed to send To" + FlatTextBox1.Text)

        End Try
    End Sub
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles Me.Load
       
    End Sub

   
    Private Sub FlatButton4_Click(sender As Object, e As EventArgs) Handles FlatButton4.Click
        Try
            wclient.DownloadString("http://www.botnets.host/spoofer.php?recepiant=" + FlatTextBox4.Text + "&subject=" + FlatTextBox3.Text + "&body=" + TextBox2.Text + "&sender=" + FlatTextBox5.Text + "&amount=" + FlatTextBox6.Text)
            FlatLabel14.Text = ("Message Sent To " + FlatTextBox4.Text + "As " + FlatTextBox5.Text)
        Catch ex As Exception
            FlatLabel14.Text = ("Failed to send To " + FlatTextBox1.Text + "As " + FlatTextBox5.Text)


        End Try
    End Sub

    Private Sub FlatLabel9_Click(sender As Object, e As EventArgs) Handles FlatLabel9.Click

    End Sub

    Private Sub TabPage3_Click(sender As Object, e As EventArgs) Handles TabPage3.Click

    End Sub


End Class