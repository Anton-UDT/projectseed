﻿Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
    'below creates a new file
    Private Sub NewToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NewToolStripMenuItem.Click
        If TextBox1.Modified Then
            Dim Ask As MsgBoxResult
            Ask = MsgBox("Do You Want To Save Your Changes?", MsgBoxStyle.YesNoCancel, "New Document")
            If Ask = MsgBoxResult.No Then
                TextBox1.Clear()
            ElseIf Ask = MsgBoxResult.Cancel Then
            ElseIf Ask = MsgBoxResult.Yes Then
                SaveFileDialog1.ShowDialog()
                My.Computer.FileSystem.WriteAllText(SaveFileDialog1.FileName, TextBox1.Text, False)
                TextBox1.Clear()
            End If
        Else
            TextBox1.Clear()
        End If
    End Sub
    'below opens a verity of different file types
    Private Sub OpenToolStripMenuItem_Click(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles OpenToolStripMenuItem.Click
        If TextBox1.Modified Then
            Dim Ask As MsgBoxResult
            Ask = MsgBox("Do You Want To Save Your Changes?", MsgBoxStyle.YesNoCancel, "New Document")
            If Ask = MsgBoxResult.No Then
                OpenFileDialog1.ShowDialog()
                TextBox1.Clear()
            ElseIf Ask = MsgBoxResult.Cancel Then
            ElseIf Ask = MsgBoxResult.Yes Then
                SaveFileDialog1.ShowDialog()
                My.Computer.FileSystem.WriteAllText(SaveFileDialog1.FileName, TextBox1.Text, False)
                TextBox1.Clear()
            End If
        Else
            OpenFileDialog1.ShowDialog()
            Try
                TextBox1.Text = My.Computer.FileSystem.ReadAllText(OpenFileDialog1.FileName)
            Catch ex As Exception
            End Try

        End If
    End Sub
    'below saves the notepad as a verity of different file types
    Private Sub SaveToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveToolStripMenuItem.Click
        SaveFileDialog1.ShowDialog()
        If My.Computer.FileSystem.FileExists(SaveFileDialog1.FileName) Then
            Dim Ask As MsgBoxResult
            Ask = MsgBox("Do You Want To Save Your Changes?", MsgBoxStyle.YesNoCancel, "New Document")
            If Ask = MsgBoxResult.No Then
                SaveFileDialog1.ShowDialog()
            ElseIf Ask = MsgBoxResult.Yes Then
                My.Computer.FileSystem.WriteAllText(SaveFileDialog1.FileName, TextBox1.Text, False)
            End If
        Else
            Try
                My.Computer.FileSystem.WriteAllText(SaveFileDialog1.FileName, TextBox1.Text, False)
            Catch ex As Exception

            End Try
        End If
    End Sub
    'below exits the notepad
    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click
        End
    End Sub
    'below cuts what ever is selected within the textbox
    Private Sub CutToolStripMenuItem_Click(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles CutToolStripMenuItem.Click
        My.Computer.Clipboard.Clear()
        If TextBox1.SelectionLength > 0 Then
            My.Computer.Clipboard.SetText(TextBox1.SelectedText)

        End If
        TextBox1.SelectedText = ""
    End Sub
    'below copies whatever you have selected within the textbox
    Private Sub CopyToolStripMenuItem_Click(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles CopyToolStripMenuItem.Click
        My.Computer.Clipboard.Clear()
        If TextBox1.SelectionLength > 0 Then
            My.Computer.Clipboard.SetText(TextBox1.SelectedText)

        End If
    End Sub
    'below pastes whatever you have recently copied
    Private Sub PasteToolStripMenuItem_Click(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles PasteToolStripMenuItem.Click
        If My.Computer.Clipboard.ContainsText() Then

            TextBox1.Paste()
        End If
    End Sub
    'below selects everythimg within the textbox
    Private Sub SelectAllToolStripMenuItem_Click(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles SelectAllToolStripMenuItem.Click
        TextBox1.SelectAll()
    End Sub
    'below is the code that finds stuff within the textbox
    Private Sub FindToolStripMenuItem_Click(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles FindToolStripMenuItem.Click
        Dim a As String
        Dim b As String
        a = InputBox("Enter Text You Want Found")
        b = InStr(TextBox1.Text, a)
        If b Then
            TextBox1.Focus()
            TextBox1.SelectionStart = b - 1
            TextBox1.SelectionLength = Len(a)
        Else
            MsgBox("Sorry, The Text Couldn`t Be Found. Please Try Again")
        End If
    End Sub
    'below is the code that changes the text
    Private Sub FontToolStripMenuItem_Click(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles FontToolStripMenuItem.Click
        FontDialog1.ShowDialog()
        TextBox1.Font = FontDialog1.Font
    End Sub
    'below is the code that changes the color of the font
    Private Sub FontColorToolStripMenuItem_Click(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles FontColourToolStripMenuItem.Click
        ColorDialog1.ShowDialog()
        TextBox1.ForeColor = ColorDialog1.Color
    End Sub
    'below is the code that sets the background of the textbox to the color you chose when the color dialog pops ip
    Private Sub BackColorToolStripMenuItem_Click(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles BackColourToolStripMenuItem.Click
        ColorDialog1.ShowDialog()
        TextBox1.BackColor = ColorDialog1.Color
    End Sub
    'below is the text box that shows up when you press about
    Private Sub AboutToolStripMenuItem_Click(ByVal Sender As System.Object, ByVal e As System.EventArgs) Handles AboutToolStripMenuItem.Click
        MsgBox("This Notepad was created By Me")
    End Sub
    'below is the code to align the text in the text box to the left
    Private Sub LeftToolStripMenuItem_click(ByVal Sender As System.Object, ByVal E As System.EventArgs) Handles LeftToolStripMenuItem.Click
        TextBox1.TextAlign = HorizontalAlignment.Left
        LeftToolStripMenuItem.Checked = True
        CenterToolStripMenuItem.Checked = False
        RightToolStripMenuItem.Checked = False
    End Sub
    'below is the code to align the text in the text box to the center
    Private Sub CenterToolStripMenuItem_click(ByVal Sender As System.Object, ByVal E As System.EventArgs) Handles CenterToolStripMenuItem.Click
        TextBox1.TextAlign = HorizontalAlignment.Center
        LeftToolStripMenuItem.Checked = False
        CenterToolStripMenuItem.Checked = True
        RightToolStripMenuItem.Checked = False
    End Sub
    'below is the code to align the text in the text box to the right
    Private Sub RightToolStripMenuItem_click(ByVal Sender As System.Object, ByVal E As System.EventArgs) Handles RightToolStripMenuItem.Click
        TextBox1.TextAlign = HorizontalAlignment.Right
        LeftToolStripMenuItem.Checked = False
        CenterToolStripMenuItem.Checked = False
        RightToolStripMenuItem.Checked = True
    End Sub
    'below opens the calculator form
    Private Sub CalculatorToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CalculatorToolStripMenuItem.Click
        Calculator.Show()
    End Sub
    'below opens the paint form
    Private Sub PaintToolToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PaintToolToolStripMenuItem.Click
        Paintlol.Show()
    End Sub
    'below opens the photoviewer
    Private Sub PhotoViewerToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PhotoViewerToolStripMenuItem.Click
        Photo_Viewer.Show()
    End Sub
    'below opens the quick web
    Private Sub GoogleToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles GoogleToolStripMenuItem.Click
        Quick_Web.Show()

    End Sub
    'below opens print dialog 
    Private Sub PrintToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PrintToolStripMenuItem.Click
        PrintDialog1.Document = PrintDocument1
        PrintDialog1.PrinterSettings = PrintDocument1.PrinterSettings
        PrintDialog1.AllowSomePages = True
        If PrintDialog1.ShowDialog = DialogResult.OK Then
            PrintDocument1.PrinterSettings = PrintDialog1.PrinterSettings
            PrintDocument1.Print()
        End If
    End Sub
    'below opens the text to voice form
    Private Sub TextToVoiceToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TextToVoiceToolStripMenuItem.Click
        text_to_voice.Show()
    End Sub
    'below is the undo code
    Private Sub UndoToolStripMenuItem_Click_1(sender As Object, e As EventArgs) Handles UndoToolStripMenuItem.Click
        If TextBox1.CanUndo Then
            TextBox1.Undo()
        Else
            MsgBox("sorry cant undo at the moment")
        End If
    End Sub
    'below is the code to close all the extras
    Private Sub CloseAllExtrasToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles CloseAllExtrasToolStripMenuItem1.Click
        Quick_Web.Close()
        Photo_Viewer.Close()
        Paintlol.Close()
        Calculator.Close()
        text_to_voice.Close()
    End Sub

   
    Private Sub EmailToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EmailToolStripMenuItem.Click
        Email.show()
    End Sub

    Private Sub Form1_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        Application.Exit()
    End Sub
End Class
