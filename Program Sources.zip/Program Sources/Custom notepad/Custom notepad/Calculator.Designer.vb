﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Calculator
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.AnswerBoxtxt = New System.Windows.Forms.TextBox()
        Me.Button1txt = New System.Windows.Forms.Button()
        Me.Button2txt = New System.Windows.Forms.Button()
        Me.Button3txt = New System.Windows.Forms.Button()
        Me.Button4txt = New System.Windows.Forms.Button()
        Me.Button5txt = New System.Windows.Forms.Button()
        Me.Button6txt = New System.Windows.Forms.Button()
        Me.Button7txt = New System.Windows.Forms.Button()
        Me.Button8txt = New System.Windows.Forms.Button()
        Me.Button9txt = New System.Windows.Forms.Button()
        Me.Plustxt = New System.Windows.Forms.Button()
        Me.Timestxt = New System.Windows.Forms.Button()
        Me.Subtracttxt = New System.Windows.Forms.Button()
        Me.Dividetxt = New System.Windows.Forms.Button()
        Me.Equalstxt = New System.Windows.Forms.Button()
        Me.Cleartxt = New System.Windows.Forms.Button()
        Me.Button0txt = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'AnswerBoxtxt
        '
        Me.AnswerBoxtxt.Location = New System.Drawing.Point(47, 22)
        Me.AnswerBoxtxt.Name = "AnswerBoxtxt"
        Me.AnswerBoxtxt.Size = New System.Drawing.Size(217, 20)
        Me.AnswerBoxtxt.TabIndex = 0
        '
        'Button1txt
        '
        Me.Button1txt.Location = New System.Drawing.Point(30, 90)
        Me.Button1txt.Name = "Button1txt"
        Me.Button1txt.Size = New System.Drawing.Size(75, 23)
        Me.Button1txt.TabIndex = 1
        Me.Button1txt.Text = "1"
        Me.Button1txt.UseVisualStyleBackColor = True
        '
        'Button2txt
        '
        Me.Button2txt.Location = New System.Drawing.Point(111, 90)
        Me.Button2txt.Name = "Button2txt"
        Me.Button2txt.Size = New System.Drawing.Size(75, 23)
        Me.Button2txt.TabIndex = 2
        Me.Button2txt.Text = "2"
        Me.Button2txt.UseVisualStyleBackColor = True
        '
        'Button3txt
        '
        Me.Button3txt.Location = New System.Drawing.Point(192, 90)
        Me.Button3txt.Name = "Button3txt"
        Me.Button3txt.Size = New System.Drawing.Size(75, 23)
        Me.Button3txt.TabIndex = 3
        Me.Button3txt.Text = "3"
        Me.Button3txt.UseVisualStyleBackColor = True
        '
        'Button4txt
        '
        Me.Button4txt.Location = New System.Drawing.Point(30, 131)
        Me.Button4txt.Name = "Button4txt"
        Me.Button4txt.Size = New System.Drawing.Size(75, 23)
        Me.Button4txt.TabIndex = 4
        Me.Button4txt.Text = "4"
        Me.Button4txt.UseVisualStyleBackColor = True
        '
        'Button5txt
        '
        Me.Button5txt.Location = New System.Drawing.Point(111, 131)
        Me.Button5txt.Name = "Button5txt"
        Me.Button5txt.Size = New System.Drawing.Size(75, 23)
        Me.Button5txt.TabIndex = 5
        Me.Button5txt.Text = "5"
        Me.Button5txt.UseVisualStyleBackColor = True
        '
        'Button6txt
        '
        Me.Button6txt.Location = New System.Drawing.Point(192, 131)
        Me.Button6txt.Name = "Button6txt"
        Me.Button6txt.Size = New System.Drawing.Size(75, 23)
        Me.Button6txt.TabIndex = 6
        Me.Button6txt.Text = "6"
        Me.Button6txt.UseVisualStyleBackColor = True
        '
        'Button7txt
        '
        Me.Button7txt.Location = New System.Drawing.Point(30, 173)
        Me.Button7txt.Name = "Button7txt"
        Me.Button7txt.Size = New System.Drawing.Size(75, 23)
        Me.Button7txt.TabIndex = 7
        Me.Button7txt.Text = "7"
        Me.Button7txt.UseVisualStyleBackColor = True
        '
        'Button8txt
        '
        Me.Button8txt.Location = New System.Drawing.Point(111, 173)
        Me.Button8txt.Name = "Button8txt"
        Me.Button8txt.Size = New System.Drawing.Size(75, 23)
        Me.Button8txt.TabIndex = 8
        Me.Button8txt.Text = "8"
        Me.Button8txt.UseVisualStyleBackColor = True
        '
        'Button9txt
        '
        Me.Button9txt.Location = New System.Drawing.Point(192, 173)
        Me.Button9txt.Name = "Button9txt"
        Me.Button9txt.Size = New System.Drawing.Size(75, 23)
        Me.Button9txt.TabIndex = 9
        Me.Button9txt.Text = "9"
        Me.Button9txt.UseVisualStyleBackColor = True
        '
        'Plustxt
        '
        Me.Plustxt.Location = New System.Drawing.Point(30, 222)
        Me.Plustxt.Name = "Plustxt"
        Me.Plustxt.Size = New System.Drawing.Size(75, 23)
        Me.Plustxt.TabIndex = 10
        Me.Plustxt.Text = "Plus"
        Me.Plustxt.UseVisualStyleBackColor = True
        '
        'Timestxt
        '
        Me.Timestxt.Location = New System.Drawing.Point(111, 222)
        Me.Timestxt.Name = "Timestxt"
        Me.Timestxt.Size = New System.Drawing.Size(75, 23)
        Me.Timestxt.TabIndex = 11
        Me.Timestxt.Text = "Tines"
        Me.Timestxt.UseVisualStyleBackColor = True
        '
        'Subtracttxt
        '
        Me.Subtracttxt.Location = New System.Drawing.Point(30, 251)
        Me.Subtracttxt.Name = "Subtracttxt"
        Me.Subtracttxt.Size = New System.Drawing.Size(75, 23)
        Me.Subtracttxt.TabIndex = 12
        Me.Subtracttxt.Text = "Subtract"
        Me.Subtracttxt.UseVisualStyleBackColor = True
        '
        'Dividetxt
        '
        Me.Dividetxt.Location = New System.Drawing.Point(111, 251)
        Me.Dividetxt.Name = "Dividetxt"
        Me.Dividetxt.Size = New System.Drawing.Size(75, 23)
        Me.Dividetxt.TabIndex = 13
        Me.Dividetxt.Text = "Divide"
        Me.Dividetxt.UseVisualStyleBackColor = True
        '
        'Equalstxt
        '
        Me.Equalstxt.Location = New System.Drawing.Point(230, 232)
        Me.Equalstxt.Name = "Equalstxt"
        Me.Equalstxt.Size = New System.Drawing.Size(75, 23)
        Me.Equalstxt.TabIndex = 14
        Me.Equalstxt.Text = "Equals"
        Me.Equalstxt.UseVisualStyleBackColor = True
        '
        'Cleartxt
        '
        Me.Cleartxt.Location = New System.Drawing.Point(230, 261)
        Me.Cleartxt.Name = "Cleartxt"
        Me.Cleartxt.Size = New System.Drawing.Size(75, 23)
        Me.Cleartxt.TabIndex = 15
        Me.Cleartxt.Text = "Clear"
        Me.Cleartxt.UseVisualStyleBackColor = True
        '
        'Button0txt
        '
        Me.Button0txt.Location = New System.Drawing.Point(111, 61)
        Me.Button0txt.Name = "Button0txt"
        Me.Button0txt.Size = New System.Drawing.Size(75, 23)
        Me.Button0txt.TabIndex = 16
        Me.Button0txt.Text = "0"
        Me.Button0txt.UseVisualStyleBackColor = True
        '
        'Calculator
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.ClientSize = New System.Drawing.Size(317, 295)
        Me.Controls.Add(Me.Button0txt)
        Me.Controls.Add(Me.Cleartxt)
        Me.Controls.Add(Me.Equalstxt)
        Me.Controls.Add(Me.Dividetxt)
        Me.Controls.Add(Me.Subtracttxt)
        Me.Controls.Add(Me.Timestxt)
        Me.Controls.Add(Me.Plustxt)
        Me.Controls.Add(Me.Button9txt)
        Me.Controls.Add(Me.Button8txt)
        Me.Controls.Add(Me.Button7txt)
        Me.Controls.Add(Me.Button6txt)
        Me.Controls.Add(Me.Button5txt)
        Me.Controls.Add(Me.Button4txt)
        Me.Controls.Add(Me.Button3txt)
        Me.Controls.Add(Me.Button2txt)
        Me.Controls.Add(Me.Button1txt)
        Me.Controls.Add(Me.AnswerBoxtxt)
        Me.Name = "Calculator"
        Me.Text = "Calculator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents AnswerBoxtxt As System.Windows.Forms.TextBox
    Friend WithEvents Button1txt As System.Windows.Forms.Button
    Friend WithEvents Button2txt As System.Windows.Forms.Button
    Friend WithEvents Button3txt As System.Windows.Forms.Button
    Friend WithEvents Button4txt As System.Windows.Forms.Button
    Friend WithEvents Button5txt As System.Windows.Forms.Button
    Friend WithEvents Button6txt As System.Windows.Forms.Button
    Friend WithEvents Button7txt As System.Windows.Forms.Button
    Friend WithEvents Button8txt As System.Windows.Forms.Button
    Friend WithEvents Button9txt As System.Windows.Forms.Button
    Friend WithEvents Plustxt As System.Windows.Forms.Button
    Friend WithEvents Timestxt As System.Windows.Forms.Button
    Friend WithEvents Subtracttxt As System.Windows.Forms.Button
    Friend WithEvents Dividetxt As System.Windows.Forms.Button
    Friend WithEvents Equalstxt As System.Windows.Forms.Button
    Friend WithEvents Cleartxt As System.Windows.Forms.Button
    Friend WithEvents Button0txt As System.Windows.Forms.Button
End Class
