﻿Public Class Calculator
    Dim firstNumber As Integer
    Dim secondNumber, answer As Integer
    Dim mathsButton As String

    Private Sub Calculator_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        AnswerBoxtxt.Text = ""
    End Sub
    Private Sub Button1txt_Click(sender As Object, e As EventArgs) Handles Button1txt.Click
        AnswerBoxtxt.Text = AnswerBoxtxt.Text + "1"
    End Sub

    Private Sub Button2txt_Click(sender As Object, e As EventArgs) Handles Button2txt.Click
        AnswerBoxtxt.Text = AnswerBoxtxt.Text + "2"
    End Sub

    Private Sub Button3txt_Click(sender As Object, e As EventArgs) Handles Button3txt.Click
        AnswerBoxtxt.Text = AnswerBoxtxt.Text + "3"
    End Sub

    Private Sub Button4txt_Click(sender As Object, e As EventArgs) Handles Button4txt.Click
        AnswerBoxtxt.Text = AnswerBoxtxt.Text + "4"
    End Sub

    Private Sub Button5txt_Click(sender As Object, e As EventArgs) Handles Button5txt.Click
        AnswerBoxtxt.Text = AnswerBoxtxt.Text + "5"
    End Sub

    Private Sub Button6txt_Click(sender As Object, e As EventArgs) Handles Button6txt.Click
        AnswerBoxtxt.Text = AnswerBoxtxt.Text + "6"
    End Sub

    Private Sub Button7txt_Click(sender As Object, e As EventArgs) Handles Button7txt.Click
        AnswerBoxtxt.Text = AnswerBoxtxt.Text + "7"
    End Sub

    Private Sub Button8txt_Click(sender As Object, e As EventArgs) Handles Button8txt.Click
        AnswerBoxtxt.Text = AnswerBoxtxt.Text + "8"
    End Sub

    Private Sub Button9txt_Click(sender As Object, e As EventArgs) Handles Button9txt.Click
        AnswerBoxtxt.Text = AnswerBoxtxt.Text + "9"
    End Sub

    Private Sub Plustxt_Click(sender As Object, e As EventArgs) Handles Plustxt.Click
        mathsButton = "Plus"

        firstNumber = Val(AnswerBoxtxt.Text)
        AnswerBoxtxt.Text = " "

    End Sub

    Private Sub Timestxt_Click(sender As Object, e As EventArgs) Handles Timestxt.Click
        mathsButton = "Times"

        firstNumber = Val(AnswerBoxtxt.Text)
        AnswerBoxtxt.Text = " "
    End Sub

    Private Sub Subtracttxt_Click(sender As Object, e As EventArgs) Handles Subtracttxt.Click
        mathsButton = "Minus"

        firstNumber = Val(AnswerBoxtxt.Text)
        AnswerBoxtxt.Text = " "
    End Sub

    Private Sub Dividetxt_Click(sender As Object, e As EventArgs) Handles Dividetxt.Click
        mathsButton = "Divide"

        firstNumber = Val(AnswerBoxtxt.Text)
        AnswerBoxtxt.Text = " "
    End Sub

    Private Sub Equalstxt_Click(sender As Object, e As EventArgs) Handles Equalstxt.Click
        secondNumber = Val(AnswerBoxtxt.Text)
        Select Case mathsButton
            Case Is = "Plus"
                answer = firstNumber + secondNumber

            Case Is = "Minus"
                answer = firstNumber - secondNumber

            Case Is = "Times"
                answer = firstNumber * secondNumber

            Case Is = "Divide"
                answer = firstNumber / secondNumber


        End Select
        AnswerBoxtxt.Text = answer
    End Sub

    Private Sub Cleartxt_Click(sender As Object, e As EventArgs) Handles Cleartxt.Click
        AnswerBoxtxt.Text = ""
    End Sub


    Private Sub Button0txt_Click(sender As Object, e As EventArgs) Handles Button0txt.Click
        AnswerBoxtxt.Text = AnswerBoxtxt.Text + "0"
    End Sub
End Class