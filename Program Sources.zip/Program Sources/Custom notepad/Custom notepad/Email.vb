﻿Imports System.Net.Mail

Public Class Email
    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        Timer1.Start()
    End Sub

    
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        ProgressBar1.Increment(5)
        If ProgressBar1.Value = 100 Then
            Timer1.Stop()
            Try
                Dim SmtpServer As New SmtpClient(TextBox6.Text)
                Dim mail As New MailMessage()

                SmtpServer.Credentials = New System.Net.NetworkCredential(TextBox5.Text, TextBox4.Text)
                SmtpServer.EnableSsl = True
                SmtpServer.Port = 587
                mail = New MailMessage()
                mail.From = New MailAddress(TextBox5.Text) 'from
                mail.To.Add(TextBox1.Text) 'to
                mail.Subject = (TextBox2.Text) 'subject
                mail.Body = (TextBox3.Text) 'email
                SmtpServer.Send(mail)
                'from

                Label7.Text = ("Email Sent to: " + TextBox1.Text)
                Label11.Text = ""
                'priority check buttons (dont seam to work)
                If RadioButton1.Checked Then
                    mail.Priority = MailPriority.Low
                ElseIf RadioButton2.Checked Then
                    mail.Priority = MailPriority.Normal
                ElseIf RadioButton3.Checked Then
                    mail.Priority = MailPriority.High
                Else
                    mail.Priority = MailPriority.Normal
                End If


            Catch ex As Exception
                Label7.Text = ""
                Label11.Text = "Email Failed, Please Try Again"
            End Try
        End If








    End Sub
End Class