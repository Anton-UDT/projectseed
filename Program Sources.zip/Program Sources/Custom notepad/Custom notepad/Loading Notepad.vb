﻿Public Class Loading_Notepad

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub
    Private Sub Loading_Notepad_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Button2.Enabled = False



    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        ProgressBar1.Increment(6)
        Label1.Text = ("Status: " + ProgressBar1.Value.ToString)
        If ProgressBar1.Value = 100 Then
            Form1.Show()
            Timer1.Stop()
            Me.Hide()
            Label1.Text = ("Status: Complete")
        End If
    End Sub

    Private Sub TrackBar1_Scroll(sender As Object, e As EventArgs) Handles TrackBar1.Scroll

    End Sub

    Private Sub TrackBar2_Scroll(sender As Object, e As EventArgs) Handles TrackBar2.Scroll

    End Sub

    Private Sub TrackBar3_Scroll(sender As Object, e As EventArgs) Handles TrackBar3.Scroll

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If TextBox1.Text = "Test" And TrackBar1.Value.ToString = "9999" And TrackBar2.Value.ToString = "9999" And TrackBar3.Value.ToString = "9999" Then
            Timer1.Start()
            Button2.Enabled = False
        End If
    End Sub

    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton1.CheckedChanged
        Button2.Enabled = True
        RadioButton1.Enabled = False
    End Sub

    Private Sub TrackBar1_ValueChanged(sender As Object, e As EventArgs) Handles TrackBar1.ValueChanged
        Label2.Text = ("Value: " + TrackBar1.Value.ToString)
    End Sub
    Private Sub TrackBar2_ValueChanged(sender As Object, e As EventArgs) Handles TrackBar2.ValueChanged
        Label3.Text = ("Value: " + TrackBar2.Value.ToString)
    End Sub
    Private Sub TrackBar3_ValueChanged(sender As Object, e As EventArgs) Handles TrackBar3.ValueChanged
        Label4.Text = ("Value: " + TrackBar3.Value.ToString)
    End Sub

    
End Class