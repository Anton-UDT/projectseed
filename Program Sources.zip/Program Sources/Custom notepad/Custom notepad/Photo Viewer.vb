﻿Public Class Photo_Viewer

    Private Sub Photo_Viewer_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        'This is show a picture
        Try
            If OpenFileDialog1.ShowDialog() = Windows.Forms.DialogResult.OK Then
                PictureBox1.Load(OpenFileDialog1.FileName)
            End If
        Catch ex As Exception
            MsgBox("sorry this isnt working at the moment")
        End Try
       

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        'this is close the picture
        Me.Close()

    End Sub


    
End Class