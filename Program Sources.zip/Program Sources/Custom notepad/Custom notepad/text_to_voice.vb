﻿Public Class text_to_voice

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        MsgBox("just type something into the textbox, thn press activate")
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim The_voice_in_your_head
        The_voice_in_your_head = CreateObject("SAPI.spvoice")
        The_voice_in_your_head.Speak(TextBox1.Text)
    End Sub
End Class