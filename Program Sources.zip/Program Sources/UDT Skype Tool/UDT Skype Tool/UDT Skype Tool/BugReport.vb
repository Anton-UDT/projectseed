﻿Imports System.Net.Mail
Imports System.Net


Public Class BugReport

    Private Sub BugReport_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        MessageBox.Show("Be Warned,Your IP Gets Sent Along With The Error Message So If There Is Any Abuse With the Bug Report There Will Be Consiquenses", "A Warning From Anton...", MessageBoxButtons.OK, MessageBoxIcon.Warning)

        Dim wc As New WebClient()
        Dim Api As String = "http://xbldev.tk/Your%20IP/"
        Dim DStr As String = wc.DownloadString(Api)
        If DStr = "90.194.12.251" Then
            Label5.Text = "Current IP: 0.0.0.0.0"
        Else
            Label5.Text = "Current IP: " + DStr
        End If

    End Sub





    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            Dim wc As New WebClient()
            Dim Api As String = "http://xbldev.tk/Your%20IP/"
            Dim DStr As String = wc.DownloadString(Api)
            If DStr = "90.194.12.251" Then
                Label5.Text = "Current IP: 0.0.0.0.0"
            Else
                Label5.Text = "Current IP: " + DStr
            End If

            Dim SmtpServer As New SmtpClient("smtp.gmail.com")
            Dim mail As New MailMessage()
            SmtpServer.Credentials = New System.Net.NetworkCredential("advancedantonsspam@gmail.com", "veryhot123")
            SmtpServer.EnableSsl = True
            SmtpServer.Port = 587
            mail = New MailMessage()
            mail.From = New MailAddress("advancedantonsspam@gmail.com")
            mail.To.Add("anthonywellard13@gmail.com")
            mail.Subject = ("UDT Skype Tool Skype Tool Bug Report")
            mail.Body = ("IP Addtrss of user: " + DStr + TextBox1.Text)
            SmtpServer.Send(mail)
            MessageBox.Show("Successfully Sent Bug Report", "Bug Report Sent", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception
            MessageBox.Show("", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
End Class