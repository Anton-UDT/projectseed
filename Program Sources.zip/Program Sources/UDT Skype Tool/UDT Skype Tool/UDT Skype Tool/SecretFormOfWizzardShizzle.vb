﻿Public Class SecretFormOfWizzardShizzle
    Public WithEvents skype1 As New SKYPE4COMLib.Skype
    Private Sub Button12_Click(sender As Object, e As EventArgs)
        Try
            TextBox10.Text = skype1.User(TextBox7.Text).FullName.ToString
        Catch ex As Exception

        End Try
    End Sub


    Private Sub Button13_Click(sender As Object, e As EventArgs)
        Try
            Dim web As New System.Net.WebClient()
            Dim results As String = web.DownloadString("")
        Catch ex As Exception

        End Try



    End Sub
End Class