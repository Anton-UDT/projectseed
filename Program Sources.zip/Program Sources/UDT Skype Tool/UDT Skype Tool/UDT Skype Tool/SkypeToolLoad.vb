﻿Public Class SkypeToolLoad


    Private Sub SkypeToolLoad_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer1.Enabled = True
       
        
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Try
            ProgressBar1.Increment(10)
            If ProgressBar1.Value = "100" Then
                UDTskypeTool.Show()
                Timer1.Enabled = False
                Me.Close()

            End If


        Catch ex As Exception

        End Try
    End Sub
End Class