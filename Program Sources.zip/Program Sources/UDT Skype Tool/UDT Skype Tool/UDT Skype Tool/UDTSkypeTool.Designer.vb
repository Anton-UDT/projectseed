﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class UDTskypeTool
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(UDTskypeTool))
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer3 = New System.Windows.Forms.Timer(Me.components)
        Me.AxSkype1 = New AxSKYPE4COMLib.AxSkype()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.TextBox9 = New System.Windows.Forms.TextBox()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.SpamMsgBtn = New System.Windows.Forms.Button()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.WebBrowser1 = New System.Windows.Forms.WebBrowser()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.SkypeStatusLoopOff = New System.Windows.Forms.Button()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.SkypeStatusLoopOn = New System.Windows.Forms.Button()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.SkypeStatusInv = New System.Windows.Forms.Button()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.SkypeStatusDND = New System.Windows.Forms.Button()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.SkypeStatusAway = New System.Windows.Forms.Button()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.SkypeStatusOffline = New System.Windows.Forms.Button()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.SkypeStatusOnline = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.SkypeMoodSpinner = New System.Windows.Forms.Button()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.SkypeMoodShader = New System.Windows.Forms.Button()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.SkypeMoodFlash = New System.Windows.Forms.Button()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SetProfileMood = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.TextBox11 = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.SkypeGenderTXT = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.SkypeMobileNoTXT = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.SkypeTimeZoneTXT = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.SkypeCountryTXT = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.SkypeBDayTXT = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.SaveSkypeProInfo = New System.Windows.Forms.Button()
        Me.GrabSkypeProInfo = New System.Windows.Forms.Button()
        Me.SkypeNameTXT = New System.Windows.Forms.TextBox()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        CType(Me.AxSkype1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage3.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Timer1
        '
        Me.Timer1.Interval = 3000
        '
        'Timer2
        '
        '
        'Timer3
        '
        '
        'AxSkype1
        '
        Me.AxSkype1.Enabled = True
        Me.AxSkype1.Location = New System.Drawing.Point(958, 708)
        Me.AxSkype1.Name = "AxSkype1"
        Me.AxSkype1.OcxState = CType(resources.GetObject("AxSkype1.OcxState"), System.Windows.Forms.AxHost.State)
        Me.AxSkype1.Size = New System.Drawing.Size(192, 192)
        Me.AxSkype1.TabIndex = 13
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.GroupBox6)
        Me.TabPage3.Controls.Add(Me.GroupBox5)
        Me.TabPage3.Controls.Add(Me.GroupBox4)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(788, 540)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Message Stuff"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.Button3)
        Me.GroupBox6.Controls.Add(Me.Label23)
        Me.GroupBox6.Controls.Add(Me.Button11)
        Me.GroupBox6.Controls.Add(Me.Label21)
        Me.GroupBox6.Controls.Add(Me.TextBox9)
        Me.GroupBox6.Location = New System.Drawing.Point(492, 39)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(200, 143)
        Me.GroupBox6.TabIndex = 3
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Spam Call User"
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(118, 108)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 23)
        Me.Button3.TabIndex = 10
        Me.Button3.Text = "Stop"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(75, 76)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(50, 13)
        Me.Label23.TabIndex = 8
        Me.Label23.Text = "Message"
        '
        'Button11
        '
        Me.Button11.Location = New System.Drawing.Point(6, 108)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(75, 23)
        Me.Button11.TabIndex = 9
        Me.Button11.Text = "Start"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(75, 26)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(55, 13)
        Me.Label21.TabIndex = 7
        Me.Label21.Text = "Username"
        '
        'TextBox9
        '
        Me.TextBox9.Location = New System.Drawing.Point(51, 42)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(100, 20)
        Me.TextBox9.TabIndex = 5
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.Button2)
        Me.GroupBox5.Controls.Add(Me.Label22)
        Me.GroupBox5.Controls.Add(Me.Label20)
        Me.GroupBox5.Controls.Add(Me.TextBox8)
        Me.GroupBox5.Controls.Add(Me.TextBox6)
        Me.GroupBox5.Controls.Add(Me.SpamMsgBtn)
        Me.GroupBox5.Location = New System.Drawing.Point(270, 39)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(200, 232)
        Me.GroupBox5.TabIndex = 2
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Spam Message To A User"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(118, 191)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 8
        Me.Button2.Text = "Stop"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(75, 76)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(50, 13)
        Me.Label22.TabIndex = 7
        Me.Label22.Text = "Message"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(75, 26)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(55, 13)
        Me.Label20.TabIndex = 6
        Me.Label20.Text = "Username"
        '
        'TextBox8
        '
        Me.TextBox8.Location = New System.Drawing.Point(51, 42)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(100, 20)
        Me.TextBox8.TabIndex = 4
        '
        'TextBox6
        '
        Me.TextBox6.Location = New System.Drawing.Point(5, 92)
        Me.TextBox6.Multiline = True
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(188, 88)
        Me.TextBox6.TabIndex = 1
        '
        'SpamMsgBtn
        '
        Me.SpamMsgBtn.Location = New System.Drawing.Point(6, 191)
        Me.SpamMsgBtn.Name = "SpamMsgBtn"
        Me.SpamMsgBtn.Size = New System.Drawing.Size(75, 23)
        Me.SpamMsgBtn.TabIndex = 0
        Me.SpamMsgBtn.Text = "Start"
        Me.SpamMsgBtn.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.TextBox5)
        Me.GroupBox4.Controls.Add(Me.Button1)
        Me.GroupBox4.Location = New System.Drawing.Point(24, 39)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(217, 163)
        Me.GroupBox4.TabIndex = 0
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Mass Message/Message To All Friends"
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(6, 21)
        Me.TextBox5.Multiline = True
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(205, 88)
        Me.TextBox5.TabIndex = 1
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(68, 120)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Send"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.Label29)
        Me.TabPage2.Controls.Add(Me.WebBrowser1)
        Me.TabPage2.Controls.Add(Me.Label28)
        Me.TabPage2.Controls.Add(Me.Button15)
        Me.TabPage2.Controls.Add(Me.Label18)
        Me.TabPage2.Controls.Add(Me.Label5)
        Me.TabPage2.Controls.Add(Me.Button5)
        Me.TabPage2.Controls.Add(Me.GroupBox3)
        Me.TabPage2.Controls.Add(Me.GroupBox1)
        Me.TabPage2.Controls.Add(Me.GroupBox2)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(788, 540)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Profile Stuff"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(490, 475)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(117, 13)
        Me.Label29.TabIndex = 1
        Me.Label29.Text = "Attached Skype Name:"
        '
        'WebBrowser1
        '
        Me.WebBrowser1.Location = New System.Drawing.Point(618, 504)
        Me.WebBrowser1.MinimumSize = New System.Drawing.Size(20, 20)
        Me.WebBrowser1.Name = "WebBrowser1"
        Me.WebBrowser1.ScrollBarsEnabled = False
        Me.WebBrowser1.Size = New System.Drawing.Size(55, 33)
        Me.WebBrowser1.TabIndex = 23
        Me.WebBrowser1.Visible = False
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(547, 508)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(63, 13)
        Me.Label28.TabIndex = 22
        Me.Label28.Text = "Current IP : "
        '
        'Button15
        '
        Me.Button15.Location = New System.Drawing.Point(60, 498)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(109, 23)
        Me.Button15.TabIndex = 21
        Me.Button15.Text = "Start Skype"
        Me.Button15.UseVisualStyleBackColor = True
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(605, 491)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(79, 13)
        Me.Label18.TabIndex = 20
        Me.Label18.Text = "Not Connected"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(460, 491)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(147, 13)
        Me.Label5.TabIndex = 18
        Me.Label5.Text = "Attached Skype Show Name:"
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(60, 470)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(109, 23)
        Me.Button5.TabIndex = 19
        Me.Button5.Text = "Connect To Skype"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.SkypeStatusLoopOff)
        Me.GroupBox3.Controls.Add(Me.Label17)
        Me.GroupBox3.Controls.Add(Me.SkypeStatusLoopOn)
        Me.GroupBox3.Controls.Add(Me.Label16)
        Me.GroupBox3.Controls.Add(Me.SkypeStatusInv)
        Me.GroupBox3.Controls.Add(Me.Label15)
        Me.GroupBox3.Controls.Add(Me.SkypeStatusDND)
        Me.GroupBox3.Controls.Add(Me.Label14)
        Me.GroupBox3.Controls.Add(Me.SkypeStatusAway)
        Me.GroupBox3.Controls.Add(Me.Label13)
        Me.GroupBox3.Controls.Add(Me.SkypeStatusOffline)
        Me.GroupBox3.Controls.Add(Me.Label12)
        Me.GroupBox3.Controls.Add(Me.SkypeStatusOnline)
        Me.GroupBox3.Location = New System.Drawing.Point(554, 20)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(197, 434)
        Me.GroupBox3.TabIndex = 16
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Status Editor"
        '
        'SkypeStatusLoopOff
        '
        Me.SkypeStatusLoopOff.Location = New System.Drawing.Point(100, 354)
        Me.SkypeStatusLoopOff.Name = "SkypeStatusLoopOff"
        Me.SkypeStatusLoopOff.Size = New System.Drawing.Size(47, 23)
        Me.SkypeStatusLoopOff.TabIndex = 23
        Me.SkypeStatusLoopOff.Text = "Off"
        Me.SkypeStatusLoopOff.UseVisualStyleBackColor = True
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(62, 338)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(64, 13)
        Me.Label17.TabIndex = 21
        Me.Label17.Text = "Loop Status"
        '
        'SkypeStatusLoopOn
        '
        Me.SkypeStatusLoopOn.Location = New System.Drawing.Point(47, 354)
        Me.SkypeStatusLoopOn.Name = "SkypeStatusLoopOn"
        Me.SkypeStatusLoopOn.Size = New System.Drawing.Size(47, 23)
        Me.SkypeStatusLoopOn.TabIndex = 22
        Me.SkypeStatusLoopOn.Text = "On"
        Me.SkypeStatusLoopOn.UseVisualStyleBackColor = True
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(71, 269)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(45, 13)
        Me.Label16.TabIndex = 19
        Me.Label16.Text = "Invisible"
        '
        'SkypeStatusInv
        '
        Me.SkypeStatusInv.Location = New System.Drawing.Point(56, 285)
        Me.SkypeStatusInv.Name = "SkypeStatusInv"
        Me.SkypeStatusInv.Size = New System.Drawing.Size(75, 23)
        Me.SkypeStatusInv.TabIndex = 20
        Me.SkypeStatusInv.Text = "Save Status"
        Me.SkypeStatusInv.UseVisualStyleBackColor = True
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(53, 206)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(77, 13)
        Me.Label15.TabIndex = 17
        Me.Label15.Text = "Do Not Disturb"
        '
        'SkypeStatusDND
        '
        Me.SkypeStatusDND.Location = New System.Drawing.Point(54, 222)
        Me.SkypeStatusDND.Name = "SkypeStatusDND"
        Me.SkypeStatusDND.Size = New System.Drawing.Size(75, 23)
        Me.SkypeStatusDND.TabIndex = 18
        Me.SkypeStatusDND.Text = "Save Status"
        Me.SkypeStatusDND.UseVisualStyleBackColor = True
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(70, 146)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(33, 13)
        Me.Label14.TabIndex = 15
        Me.Label14.Text = "Away"
        '
        'SkypeStatusAway
        '
        Me.SkypeStatusAway.Location = New System.Drawing.Point(54, 162)
        Me.SkypeStatusAway.Name = "SkypeStatusAway"
        Me.SkypeStatusAway.Size = New System.Drawing.Size(75, 23)
        Me.SkypeStatusAway.TabIndex = 16
        Me.SkypeStatusAway.Text = "Save Status"
        Me.SkypeStatusAway.UseVisualStyleBackColor = True
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(70, 88)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(37, 13)
        Me.Label13.TabIndex = 13
        Me.Label13.Text = "Offline"
        '
        'SkypeStatusOffline
        '
        Me.SkypeStatusOffline.Location = New System.Drawing.Point(54, 104)
        Me.SkypeStatusOffline.Name = "SkypeStatusOffline"
        Me.SkypeStatusOffline.Size = New System.Drawing.Size(75, 23)
        Me.SkypeStatusOffline.TabIndex = 14
        Me.SkypeStatusOffline.Text = "Save Status"
        Me.SkypeStatusOffline.UseVisualStyleBackColor = True
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(70, 23)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(37, 13)
        Me.Label12.TabIndex = 11
        Me.Label12.Text = "Online"
        '
        'SkypeStatusOnline
        '
        Me.SkypeStatusOnline.Location = New System.Drawing.Point(54, 39)
        Me.SkypeStatusOnline.Name = "SkypeStatusOnline"
        Me.SkypeStatusOnline.Size = New System.Drawing.Size(75, 23)
        Me.SkypeStatusOnline.TabIndex = 12
        Me.SkypeStatusOnline.Text = "Save Status"
        Me.SkypeStatusOnline.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.SkypeMoodSpinner)
        Me.GroupBox1.Controls.Add(Me.TextBox4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.SkypeMoodShader)
        Me.GroupBox1.Controls.Add(Me.TextBox3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.SkypeMoodFlash)
        Me.GroupBox1.Controls.Add(Me.TextBox2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.SetProfileMood)
        Me.GroupBox1.Controls.Add(Me.TextBox1)
        Me.GroupBox1.Location = New System.Drawing.Point(37, 20)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(175, 434)
        Me.GroupBox1.TabIndex = 17
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Mood Editor"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(29, 321)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(114, 13)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "Spinner Next To Mood"
        '
        'SkypeMoodSpinner
        '
        Me.SkypeMoodSpinner.Location = New System.Drawing.Point(16, 363)
        Me.SkypeMoodSpinner.Name = "SkypeMoodSpinner"
        Me.SkypeMoodSpinner.Size = New System.Drawing.Size(139, 23)
        Me.SkypeMoodSpinner.TabIndex = 9
        Me.SkypeMoodSpinner.Text = "Set Mood With Effect"
        Me.SkypeMoodSpinner.UseVisualStyleBackColor = True
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(34, 337)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(100, 20)
        Me.TextBox4.TabIndex = 8
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(31, 217)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(107, 13)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Shader Behind Mood"
        '
        'SkypeMoodShader
        '
        Me.SkypeMoodShader.Location = New System.Drawing.Point(16, 258)
        Me.SkypeMoodShader.Name = "SkypeMoodShader"
        Me.SkypeMoodShader.Size = New System.Drawing.Size(139, 23)
        Me.SkypeMoodShader.TabIndex = 6
        Me.SkypeMoodShader.Text = "Set Mood With Effect"
        Me.SkypeMoodShader.UseVisualStyleBackColor = True
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(32, 233)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(100, 20)
        Me.TextBox3.TabIndex = 5
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(35, 109)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(100, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Flashing Mood Text"
        '
        'SkypeMoodFlash
        '
        Me.SkypeMoodFlash.Location = New System.Drawing.Point(16, 151)
        Me.SkypeMoodFlash.Name = "SkypeMoodFlash"
        Me.SkypeMoodFlash.Size = New System.Drawing.Size(139, 23)
        Me.SkypeMoodFlash.TabIndex = 3
        Me.SkypeMoodFlash.Text = "Set Mood With Effects"
        Me.SkypeMoodFlash.UseVisualStyleBackColor = True
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(36, 125)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(100, 20)
        Me.TextBox2.TabIndex = 2
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(64, 14)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(34, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Mood"
        '
        'SetProfileMood
        '
        Me.SetProfileMood.Location = New System.Drawing.Point(49, 56)
        Me.SetProfileMood.Name = "SetProfileMood"
        Me.SetProfileMood.Size = New System.Drawing.Size(75, 23)
        Me.SetProfileMood.TabIndex = 1
        Me.SetProfileMood.Text = "Set Mood"
        Me.SetProfileMood.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(36, 30)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 20)
        Me.TextBox1.TabIndex = 0
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Button6)
        Me.GroupBox2.Controls.Add(Me.Label19)
        Me.GroupBox2.Controls.Add(Me.TextBox11)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.SkypeGenderTXT)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Controls.Add(Me.SkypeMobileNoTXT)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.SkypeTimeZoneTXT)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.SkypeCountryTXT)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.SkypeBDayTXT)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.SaveSkypeProInfo)
        Me.GroupBox2.Controls.Add(Me.GrabSkypeProInfo)
        Me.GroupBox2.Controls.Add(Me.SkypeNameTXT)
        Me.GroupBox2.Location = New System.Drawing.Point(279, 20)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(212, 434)
        Me.GroupBox2.TabIndex = 15
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Profile Editor"
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(59, 389)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(88, 23)
        Me.Button6.TabIndex = 26
        Me.Button6.Text = "Save Name"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(71, 347)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(68, 13)
        Me.Label19.TabIndex = 25
        Me.Label19.Text = "Skype Name"
        '
        'TextBox11
        '
        Me.TextBox11.Location = New System.Drawing.Point(52, 363)
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.Size = New System.Drawing.Size(100, 20)
        Me.TextBox11.TabIndex = 24
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(7, 264)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(42, 13)
        Me.Label10.TabIndex = 23
        Me.Label10.Text = "Gender"
        '
        'SkypeGenderTXT
        '
        Me.SkypeGenderTXT.Location = New System.Drawing.Point(106, 261)
        Me.SkypeGenderTXT.Name = "SkypeGenderTXT"
        Me.SkypeGenderTXT.Size = New System.Drawing.Size(100, 20)
        Me.SkypeGenderTXT.TabIndex = 22
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(7, 229)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(78, 13)
        Me.Label11.TabIndex = 21
        Me.Label11.Text = "Mobile Number"
        '
        'SkypeMobileNoTXT
        '
        Me.SkypeMobileNoTXT.Location = New System.Drawing.Point(106, 226)
        Me.SkypeMobileNoTXT.Name = "SkypeMobileNoTXT"
        Me.SkypeMobileNoTXT.Size = New System.Drawing.Size(100, 20)
        Me.SkypeMobileNoTXT.TabIndex = 20
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(6, 189)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(53, 13)
        Me.Label8.TabIndex = 19
        Me.Label8.Text = "Timezone"
        '
        'SkypeTimeZoneTXT
        '
        Me.SkypeTimeZoneTXT.Location = New System.Drawing.Point(106, 186)
        Me.SkypeTimeZoneTXT.Name = "SkypeTimeZoneTXT"
        Me.SkypeTimeZoneTXT.Size = New System.Drawing.Size(100, 20)
        Me.SkypeTimeZoneTXT.TabIndex = 18
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(6, 154)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(43, 13)
        Me.Label9.TabIndex = 17
        Me.Label9.Text = "Country"
        '
        'SkypeCountryTXT
        '
        Me.SkypeCountryTXT.Location = New System.Drawing.Point(106, 151)
        Me.SkypeCountryTXT.Name = "SkypeCountryTXT"
        Me.SkypeCountryTXT.Size = New System.Drawing.Size(100, 20)
        Me.SkypeCountryTXT.TabIndex = 16
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(6, 112)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(45, 13)
        Me.Label7.TabIndex = 15
        Me.Label7.Text = "Birthday"
        '
        'SkypeBDayTXT
        '
        Me.SkypeBDayTXT.Location = New System.Drawing.Point(106, 109)
        Me.SkypeBDayTXT.Name = "SkypeBDayTXT"
        Me.SkypeBDayTXT.Size = New System.Drawing.Size(100, 20)
        Me.SkypeBDayTXT.TabIndex = 14
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(6, 77)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(35, 13)
        Me.Label6.TabIndex = 13
        Me.Label6.Text = "Name"
        '
        'SaveSkypeProInfo
        '
        Me.SaveSkypeProInfo.Location = New System.Drawing.Point(63, 298)
        Me.SaveSkypeProInfo.Name = "SaveSkypeProInfo"
        Me.SaveSkypeProInfo.Size = New System.Drawing.Size(88, 23)
        Me.SaveSkypeProInfo.TabIndex = 12
        Me.SaveSkypeProInfo.Text = "Save Changes"
        Me.SaveSkypeProInfo.UseVisualStyleBackColor = True
        '
        'GrabSkypeProInfo
        '
        Me.GrabSkypeProInfo.Location = New System.Drawing.Point(63, 20)
        Me.GrabSkypeProInfo.Name = "GrabSkypeProInfo"
        Me.GrabSkypeProInfo.Size = New System.Drawing.Size(89, 23)
        Me.GrabSkypeProInfo.TabIndex = 11
        Me.GrabSkypeProInfo.Text = "Grab Your Info"
        Me.GrabSkypeProInfo.UseVisualStyleBackColor = True
        '
        'SkypeNameTXT
        '
        Me.SkypeNameTXT.Location = New System.Drawing.Point(106, 74)
        Me.SkypeNameTXT.Name = "SkypeNameTXT"
        Me.SkypeNameTXT.Size = New System.Drawing.Size(100, 20)
        Me.SkypeNameTXT.TabIndex = 11
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.Button10)
        Me.TabPage1.Controls.Add(Me.Label27)
        Me.TabPage1.Controls.Add(Me.GroupBox8)
        Me.TabPage1.Controls.Add(Me.GroupBox7)
        Me.TabPage1.Controls.Add(Me.AxSkype1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(788, 540)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Home Tab"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button10.Location = New System.Drawing.Point(304, 219)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(167, 73)
        Me.Button10.TabIndex = 18
        Me.Button10.Text = "About"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.Location = New System.Drawing.Point(117, 51)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(570, 31)
        Me.Label27.TabIndex = 19
        Me.Label27.Text = "UDT Skypt Tool V1 Created By Anton UDT"
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.Label26)
        Me.GroupBox8.Controls.Add(Me.Label25)
        Me.GroupBox8.Controls.Add(Me.Label24)
        Me.GroupBox8.Location = New System.Drawing.Point(558, 140)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(222, 222)
        Me.GroupBox8.TabIndex = 16
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "Useful Fact.."
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(16, 104)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(0, 13)
        Me.Label26.TabIndex = 19
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(16, 70)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(130, 13)
        Me.Label25.TabIndex = 18
        Me.Label25.Text = "Chicken Is High In Protein"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(6, 35)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(84, 13)
        Me.Label24.TabIndex = 17
        Me.Label24.Text = "Did You Know..."
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.Button9)
        Me.GroupBox7.Controls.Add(Me.Button8)
        Me.GroupBox7.Controls.Add(Me.Button7)
        Me.GroupBox7.Controls.Add(Me.Button4)
        Me.GroupBox7.Location = New System.Drawing.Point(8, 140)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(200, 222)
        Me.GroupBox7.TabIndex = 15
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Usefal Stuff"
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(6, 144)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(91, 23)
        Me.Button9.TabIndex = 17
        Me.Button9.Text = "Dev`s Chicken"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(6, 104)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(117, 23)
        Me.Button8.TabIndex = 16
        Me.Button8.Text = "UDT Official Website"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(6, 65)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(117, 23)
        Me.Button7.TabIndex = 15
        Me.Button7.Text = "UDT Official Youtube"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(6, 25)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(75, 23)
        Me.Button4.TabIndex = 14
        Me.Button4.Text = "Bug Report"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Location = New System.Drawing.Point(0, 0)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(796, 566)
        Me.TabControl1.TabIndex = 0
        '
        'UDTskypeTool
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(796, 566)
        Me.Controls.Add(Me.TabControl1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "UDTskypeTool"
        Me.Text = "UDT Skype Tool V1"
        CType(Me.AxSkype1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage3.ResumeLayout(False)
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox8.PerformLayout()
        Me.GroupBox7.ResumeLayout(False)
        Me.TabControl1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Timer2 As System.Windows.Forms.Timer
    Friend WithEvents Timer3 As System.Windows.Forms.Timer
    Friend WithEvents AxSkype1 As AxSKYPE4COMLib.AxSkype
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents TextBox9 As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents SpamMsgBtn As System.Windows.Forms.Button
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents WebBrowser1 As System.Windows.Forms.WebBrowser
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Button15 As System.Windows.Forms.Button
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents SkypeStatusLoopOff As System.Windows.Forms.Button
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents SkypeStatusLoopOn As System.Windows.Forms.Button
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents SkypeStatusInv As System.Windows.Forms.Button
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents SkypeStatusDND As System.Windows.Forms.Button
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents SkypeStatusAway As System.Windows.Forms.Button
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents SkypeStatusOffline As System.Windows.Forms.Button
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents SkypeStatusOnline As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents SkypeMoodSpinner As System.Windows.Forms.Button
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents SkypeMoodShader As System.Windows.Forms.Button
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents SkypeMoodFlash As System.Windows.Forms.Button
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents SetProfileMood As System.Windows.Forms.Button
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents TextBox11 As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents SkypeGenderTXT As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents SkypeMobileNoTXT As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents SkypeTimeZoneTXT As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents SkypeCountryTXT As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents SkypeBDayTXT As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents SaveSkypeProInfo As System.Windows.Forms.Button
    Friend WithEvents GrabSkypeProInfo As System.Windows.Forms.Button
    Friend WithEvents SkypeNameTXT As System.Windows.Forms.TextBox
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents GroupBox8 As System.Windows.Forms.GroupBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl

End Class
