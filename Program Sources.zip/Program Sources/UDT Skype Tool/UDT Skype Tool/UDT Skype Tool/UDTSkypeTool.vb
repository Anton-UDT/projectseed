﻿Imports System.Net


Public Class UDTskypeTool
    Public WithEvents skype1 As New SKYPE4COMLib.Skype

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Try

            AxSkype1.CurrentUserStatus = SKYPE4COMLib.TUserStatus.cusOnline
            AxSkype1.CurrentUserStatus = SKYPE4COMLib.TUserStatus.cusOffline
            AxSkype1.CurrentUserStatus = SKYPE4COMLib.TUserStatus.cusAway
            AxSkype1.CurrentUserStatus = SKYPE4COMLib.TUserStatus.cusDoNotDisturb
            AxSkype1.CurrentUserStatus = SKYPE4COMLib.TUserStatus.cusInvisible

        Catch ex As Exception

        End Try
    End Sub
    Private Sub SetProfileMood_Click_1(sender As Object, e As EventArgs) Handles SetProfileMood.Click
        Try
            AxSkype1.CurrentUserProfile.MoodText = "<a href= https://www.youtube.com/channel/UCDWc2-dFjZ3uAokXCZ12kQw>" + TextBox1.Text + "</a>"
            MessageBox.Show("Mood Successfully Changed", "Mood Change Successfull", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception
            MessageBox.Show("Oops There Was A Problem, Please Try Again And If The Problem Continues Please Send A Bug Report", "Mood Change Unsuccessfull", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub



    Private Sub SkypeMoodFlash_Click_1(sender As Object, e As EventArgs) Handles SkypeMoodFlash.Click
        Try
            AxSkype1.CurrentUserProfile.RichMoodText = ("<blink>" + TextBox2.Text + "</blink>")
            MessageBox.Show("Mood Successfully Changed", "Mood Change With Effect Successfull", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception
            MessageBox.Show("Oops There Was A Problem, Please Try Again And If The Problem Continues Please Send A Bug Report", "Mood Change Unsuccessfull", MessageBoxButtons.OK, MessageBoxIcon.Error)

        End Try
    End Sub



    Private Sub SkypeMoodShader_Click(sender As Object, e As EventArgs) Handles SkypeMoodShader.Click
        Try
            AxSkype1.CurrentUserProfile.RichMoodText = "<ZapButton Action=""resume"" Template=""MediumButtonTextDark"">" + TextBox3.Text + "</ZapButton>"
            MessageBox.Show("Successfully Changed Your Mood", "Mood Change Successfull", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception
            MessageBox.Show("Sorry But This Is Bugged And Does Not Work, I am Working Hard On Fixing It", "ERROR Bugs", MessageBoxButtons.OK, MessageBoxIcon.Error)

        End Try
    End Sub



    Private Sub SkypeMoodSpinner_Click(sender As Object, e As EventArgs) Handles SkypeMoodSpinner.Click
        Try
            AxSkype1.CurrentUserProfile.RichMoodText = ("<spinner></spinner>" + TextBox4.Text + "<spinner></spinner>")
            MessageBox.Show("Mood Successfully Changed", "Mood Change With Effect Successfull", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception
            MessageBox.Show("Oops There Was A Problem, Please Try Again And If The Problem Continues Please Send A Bug Report", "Mood Change Unsuccessfull", MessageBoxButtons.OK, MessageBoxIcon.Error)

        End Try
    End Sub



    Private Sub GrabSkypeProInfo_Click_1(sender As Object, e As EventArgs) Handles GrabSkypeProInfo.Click
        Try
            SkypeNameTXT.Text = AxSkype1.CurrentUserProfile.FullName
            SkypeBDayTXT.Text = AxSkype1.CurrentUserProfile.Birthday
            SkypeCountryTXT.Text = AxSkype1.CurrentUserProfile.Country
            SkypeTimeZoneTXT.Text = AxSkype1.CurrentUserProfile.Timezone
            SkypeMobileNoTXT.Text = AxSkype1.CurrentUserProfile.PhoneMobile
            SkypeGenderTXT.Text = AxSkype1.CurrentUserProfile.Sex
            MessageBox.Show("We Have Successfully Grabbed Your Info... Gender 1 Is Female Gender 2 Is Male", "Info Grab Successful", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception
            MessageBox.Show("Sorry There Was An Error obtaining Your Info, Please Try Again, Or send A Bug Report", "Info Grab Unsuccessfull", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub SaveSkypeProInfo_Click_1(sender As Object, e As EventArgs) Handles SaveSkypeProInfo.Click
        Try
            AxSkype1.CurrentUserProfile.FullName = SkypeNameTXT.Text
            AxSkype1.CurrentUserProfile.Birthday = SkypeBDayTXT.Text
            AxSkype1.CurrentUserProfile.Country = SkypeCountryTXT.Text
            AxSkype1.CurrentUserProfile.Timezone = SkypeTimeZoneTXT.Text
            AxSkype1.CurrentUserProfile.PhoneMobile = SkypeMobileNoTXT.Text
            AxSkype1.CurrentUserProfile.Sex = SkypeGenderTXT.Text
            MessageBox.Show("We Have Successfully Saved Your New Profile Info", "Profile Info Change Successfull", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception
            MessageBox.Show("There was an error saving your profile info")
        End Try
    End Sub

    Private Sub Button6_Click_1(sender As Object, e As EventArgs) Handles Button6.Click
        Try
            AxSkype1.CurrentUserProfile.FullName = TextBox11.Text
            Label18.Text = AxSkype1.CurrentUserProfile.FullName
            MessageBox.Show("We Have Successfully Changed Your Skype Name", "Skype Name Changed Successfully", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub SkypeStatusOnline_Click_1(sender As Object, e As EventArgs) Handles SkypeStatusOnline.Click
        Try
            AxSkype1.CurrentUserStatus = SKYPE4COMLib.TUserStatus.cusOnline
            MessageBox.Show("You Are Online", "Status: Online", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub SkypeStatusOffline_Click_1(sender As Object, e As EventArgs) Handles SkypeStatusOffline.Click
        Try
            AxSkype1.CurrentUserStatus = SKYPE4COMLib.TUserStatus.cusOffline
            MessageBox.Show("You Are Offline", "Status: Offline", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Catch ex As Exception

        End Try
    End Sub

    Private Sub SkypeStatusAway_Click_1(sender As Object, e As EventArgs) Handles SkypeStatusAway.Click
        AxSkype1.CurrentUserStatus = SKYPE4COMLib.TUserStatus.cusAway
        MessageBox.Show("You Are Away", "Status: Away", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Private Sub SkypeStatusDND_Click_1(sender As Object, e As EventArgs) Handles SkypeStatusDND.Click
        AxSkype1.CurrentUserStatus = SKYPE4COMLib.TUserStatus.cusDoNotDisturb
        MessageBox.Show("You Are Appering as Do Not Disturb", "Status: Do Not Disturb", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Private Sub SkypeStatusInv_Click_1(sender As Object, e As EventArgs) Handles SkypeStatusInv.Click
        AxSkype1.CurrentUserStatus = SKYPE4COMLib.TUserStatus.cusInvisible
        MessageBox.Show("You Are Invisble", "Status: Invisible", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Private Sub SkypeStatusLoopOn_Click_1(sender As Object, e As EventArgs) Handles SkypeStatusLoopOn.Click
        MessageBox.Show("Status Loop Activated", "Status Loopp: On", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Timer1.Enabled = True
        Timer1.Interval = "1000"
    End Sub

    Private Sub SkypeStatusLoopOff_Click_1(sender As Object, e As EventArgs) Handles SkypeStatusLoopOff.Click

        Timer1.Enabled = False
        MessageBox.Show("Status Loop Deactivated", "Status Loopp: Off", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Private Sub Button5_Click_1(sender As Object, e As EventArgs) Handles Button5.Click
        'This is connecting to your profile

        Try
            AxSkype1.Attach()
            Label18.Text = AxSkype1.CurrentUserProfile.FullName
            Label29.Text = "Attached Skype Name:" + AxSkype1.CurrentUserHandle
            Dim wc As New WebClient()
            Dim Api As String = "http://xbldev.tk/Your%20IP/"
            Dim DStr As String = wc.DownloadString(Api)
            If AxSkype1.CurrentUserHandle = "antfunai" Then
                Label28.Text = "Current IP: 0.0.0.0.0"
            Else
                Label28.Text = "Current IP: " + DStr
            End If
            MessageBox.Show("You We Have Successfully Connected Your Skype Account", "Connection Successfull", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception
            MessageBox.Show("Sorry But We Couldnt Connect To Your Skype Account, If You Havent Logged In Then Please Do Otherwise Send A Bug Report", "Connection Unsuccessfull", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Label18.Text = ("Faild Please Try Again")
        End Try
    End Sub

    Private Sub Button15_Click_1(sender As Object, e As EventArgs) Handles Button15.Click

        'this is starting a new skype window
        AxSkype1.Client.Start()
    End Sub


    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        AboutForm.Show()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        BugReport.Show()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            For Each user As SKYPE4COMLib.User In AxSkype1.Friends
                AxSkype1.SendMessage(user.Handle, TextBox5.Text + " Send to you by UDT`s Skype Tool")

            Next
            MessageBox.Show("Mass Message Successfully Sent", "Mass Message Sent", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception
            MessageBox.Show("Sorry There Was A Problem Sending A Message, If This Problem Keeps Occuring Then Please Send A Bug Report", "Message Not Sent", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    
    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        AxSkype1.SendMessage(TextBox8.Text, TextBox6.Text)
    End Sub

    Private Sub SpamMsgBtn_Click(sender As Object, e As EventArgs) Handles SpamMsgBtn.Click
        Try
            Timer2.Enabled = True
            Timer2.Interval = "1000"
            MessageBox.Show("Successfully Spammed Your Contact", "Spam Successfull", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Try
            Timer2.Enabled = False
            MessageBox.Show("Successfully Stopped Spamming Message", "Message Spam Stopped", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click
        Try
            Timer3.Enabled = True
            Timer3.Interval = "2000"
            MessageBox.Show("You have started the spam call successfully", "Spam Call Successfull", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Try
            Timer3.Enabled = False
            MessageBox.Show("Spam Call Successfully Stopped", "Stopped Spam Call")
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Timer3_Tick(sender As Object, e As EventArgs) Handles Timer3.Tick
        Try
            AxSkype1.PlaceCall(TextBox9.Text)
            AxSkype1.ActiveCalls(1).Finish()
        Catch ex As Exception
            Timer3.Enabled = False
            MessageBox.Show("There was an error connecting to your browser, please try again or send a bug report if the problem continues", "Error while connecting to browser", MessageBoxButtons.OK, MessageBoxIcon.Error)

        End Try
    End Sub


    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        Process.Start("https://www.youtube.com/channel/UCeael3ubqpy2HKaeHnQzzfg")
    End Sub


    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        DevsChicken.Show()
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        MessageBox.Show("Sorry but we dont currently have a website", "Sorry Guys", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub
End Class
