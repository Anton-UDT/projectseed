var app = angular.module("myApp", ['textAngular']);

//controller for message page ==========================================================================================
app.controller("eMessageCtrl", function($scope, $http) {
	
	var currMessage;

    function getMessage() {
        console.log("Retrieving message");
		$http({
             url: "/message/country/UK",
             method: "GET"
		}).success(function (data, status, headers, config) {
				currMessage = data;
				console.log("Message: ", currMessage);

				$scope.message = currMessage.messageText;
				$scope.messageHeading = currMessage.title;
		}).error(function (data, status, headers, config) {
            	$scope.message = "No message set";
            	$scope.messageHeading = "Message Board";
		});
    };
	
	//load message on startup
    getMessage();
	
	$scope.submitMessage = function(){
		console.log("Current message text: ", $scope.message);
		currMessage.messageText = $scope.message;
		currMessage.title = $scope.messageHeading;
		console.log("Persisting message: ", currMessage);
		$http({
             url: "/message",
             method: "POST",
			 data: currMessage
		}).success(function (data, status, headers, config) {
				console.log("Saving message: ", data);
		}).error(function (data, status, headers, config) {
				console.log("Error - message not saved.  Error code: ", status);
		});	
	};

	$scope.clearMessage = function(){
		console.log("Erasing message: ");
		$scope.message = "";
	};
});


//controller for contributions page ====================================================================================
app.controller("eContributionCtrl", function($scope, $http, $anchorScroll, $location){
    $scope.expandStyle = "expand_more";
    $scope.currSelected = -1;
    $scope.currEdit = '';
    $scope.editing = '';
    $location.hash('contributionsList');

    $scope.showReportDetails = function(contentId){
        uRLString = "/contribution/" + contentId;
        $http({
             url: uRLString,
             method: "GET",
        }).success(function (data, status, headers, config) {
                console.log("Contribution retrieved: ", data);
        }).error(function (data, status, headers, config) {
                console.log("An error has occurred when retrieving messages: ", status);
        });
    }

	$scope.showReport = function(contentId, reportIndex) {
		var newHash = "storyEditor-" + reportIndex;
        if ($location.hash() != newHash) {  // set the $location.hash to `newHash` and $anchorScroll will automatically scroll to it
            $location.hash(newHash);
        } else {  // call $anchorScroll() explicitly, since $location.hash hasn't changed
            $anchorScroll();
        }
	    if(reportIndex == $scope.currSelected)
	        $scope.currSelected = -1;
	    else
            $scope.currSelected = reportIndex;
        console.log("Selected report", reportIndex);
        $scope.expandStyle = "expand_less";
	  //get the selected contribution by its ID
	  
	  uRLString = "/contribution/" + contentId;
	  
		$http({
			 url: uRLString,
			 method: "GET",
		}).success(function (data, status, headers, config) {
				console.log("Messages retrieved: ", data);
				$scope.newStory = createNewStory(data);
				$scope.currEdit = $scope.newStory.reportText;
                $scope.editing = 'reportText';
		}).error(function (data, status, headers, config) {
				console.log("An error has occurred when retrieving messages: ", status);
		});		  
    };
	
	function createNewStory(contributionData){
		var newStory = [];
		console.log("Original contribution data", contributionData);
		newStory.push({"contentId":contributionData.contentId,
						"contentType":"STORY",
						"title":contributionData.title,
						"creatorId":contributionData.creatorId,
						"originator":contributionData.originator,
						"creationTimestamp":Math.floor(Date.now()),
						"shares":null,
						"country":contributionData.country,
						"status":"SUBMITTED",
						"serialId":contributionData.serialId,
						"reportText":contributionData.reportText,
						"imageId":contributionData.imageId,
						"videoId":contributionData.videoId,
						"audioId":contributionData.audioId,
						"headline":"",
						"commentary":"",
						"url":"",
						"citizenReport":contributionData.citizenReport,
						"mediaWatch":contributionData.mediaWatch,
						"featuredContribution":contributionData.featuredContribution
					});
		$scope.imageUrl = "https://media1.britannica.com/eb-media/25/93825-004-A21EC811.jpg";			
		console.log("Setting up a new story", newStory[0]);
		return newStory[0];
	};

	$scope.sortType = "title";
    $scope.sortReverse = false;

    $scope.setSort = function(typeToSort){
        if($scope.currSelected == -1){
            $scope.sortType = typeToSort;
            $scope.sortReverse = !($scope.sortReverse);
        }

    };

	function getContributionList(){
		$http({
			 url: "/contributions/country/UK",
			 method: "GET",
		}).success(function (data, status, headers, config) {
				console.log("Messages retrieved: ", data);
				$scope.contributions = data;
		}).error(function (data, status, headers, config) {
				console.log("An error has occurred when retrieving contributions: ", status);
		});	
	};
	getContributionList();
	
	$scope.saveReport = function(){
		$http({
			 url: "/story",
			 method: "POST",
			 data: $scope.newStory
		}).success(function (data, status, headers, config) {
				console.log("Story saved: ", data);
		}).error(function (data, status, headers, config) {
				console.log("An error occurred, your story has not been saved.  Please try again.  Error code: ", status);
		});	
	};
	
	$scope.backToTop = function(){
	var newHash = "contributionsList";
      if ($location.hash() !== newHash) {
        // set the $location.hash to `newHash` and
        // $anchorScroll will automatically scroll to it
        $location.hash(newHash);
      } else {
        // call $anchorScroll() explicitly,
        // since $location.hash hasn't changed
        $anchorScroll();
      }
      $scope.expandStyle = "expand_more"
      $scope.currSelected = -1;
	};;
	
	$scope.previewStory = function(){
		console.log("Previewing current story");
		$('#storyPreview').css('display','block');
	}
	
	$scope.getFormattedDate = function(dateToFormat){
		return new Date($scope.newStory.creationTimestamp, longDate);
	}
	
	$scope.closeStoryModal = function(){
		console.log("Closing preview modal");
		$('#storyPreview').css('display','none');
	}
	

	$scope.quarantineReport = function() {
	    console.log("quarantining report");
	}

	$scope.publishReport = function() {
	    console.log("publishing report");
	}

	//editing functions ================================================================================================

    $scope.saveDraft = function(){
 	    if($scope.editing == 'headline'){ $scope.newStory.headline = $scope.currEdit;}
 	    else if($scope.editing == 'reportText'){ $scope.newStory.reportText = $scope.currEdit;}
 	    else if($scope.editing == 'commentary'){ $scope.newStory.commentary = $scope.currEdit;}
 	    console.log("Finished editing", $scope.editing, $scope.currEdit);
 	    $scope.currEdit = '';
 	    $scope.editing = '';
    }

	$scope.editText = function(editable){
	    if(editable == 'headline'){
	        $scope.currEdit = $scope.newStory.headline;
	    }
	    else if(editable == 'reportText'){
            $scope.currEdit = $scope.newStory.reportText;
	    }
	    else if(editable == 'commentary'){
	        $scope.currEdit = $scope.newStory.commentary;
	    }
	    $scope.editing = editable;
        console.log("currently editing", editable, $scope.currEdit);
	}

	$scope.editImage = function(){

	}

	$scope.editVideo = function(){

	}

	$scope.editAudio = function(){

	}
});

app.controller("wVideoCtrl", function($scope){
    $scope.uploadVideo = function(){
        $('#videoFile').css('display','block');
        // get the reference to the actual file in the input
        var theFormFile = $('#theFile').get()[0].files[0];

        console.log("Uploading this video: ", theFormFile);
    }
    /*
        $.ajax({
          type: 'PUT',
          url: "<YOUR_PRE_SIGNED_UPLOAD_URL_HERE>",
          // Content type must much with the parameter you signed your URL with
          contentType: 'binary/octet-stream',
          // this flag is important, if not set, it will try to send data as a form
          processData: false,
          // the actual file is sent raw
          data: theFormFile
        })
        .success(function() {
          alert('File uploaded');
        })
        .error(function() {
          alert('File NOT uploaded');
          console.log( arguments);
        });

        return false;

    */

});

//Text Editor configuration
app.config(['$provide', function($provide){
		// register a new tool and add it to the default toolbar
		$provide.decorator('taOptions', ['taRegisterTool', 'taSelection', 'taBrowserTag', 'taTranslations',
                                             'taToolFunctions', '$delegate',
                                             function(taRegisterTool, taSelection, taBrowserTag, taTranslations,
                                                      taToolFunctions, taOptions){
			// $delegate is the taOptions we are decorating
			// here we override the default toolbars and classes specified in taOptions.
			taOptions.forceTextAngularSanitize = true; // set false to allow the textAngular-sanitize provider to be replaced
			taOptions.keyMappings = []; // allow customizable keyMappings for specialized key boards or languages
			taOptions.toolbar = [['h1','h4','h6','bold','italics','insertLink','fontColor','undo']];
			taOptions.classes = {
				focussed: 'focussed',
				toolbar: 'btn-toolbar',
				toolbarGroup: 'btn-group',
				toolbarButton: 'btn btn-default',
				toolbarButtonActive: 'active',
				disabled: 'disabled',
				textEditor: 'form-control',
				htmlEditor: 'form-control'
			};
			return taOptions; // taOptions are provided to the decorator which can format the styling of those options
		}])
	}]);


app.config(function($provide){
	$provide.decorator('taOptions', ['taRegisterTool', '$delegate', function(taRegisterTool, taOptions){  // $delegate is the taOptions we are decorating
		// register the tool with textAngular
		taRegisterTool('fontGrow', {
        		        buttontext: "<i class='material-icons'>format_size</i>",
        		        action: function(){
        		            this.$editor().wrapSelection('fontSize', '5em');
        		        }
        });
		taRegisterTool('fontDefault', {
		                buttontext: "<i class='material-icons'>title</i>",
        		        action: function(){
        		            this.$editor().wrapSelection('fontSize', '3em');
        		        }
        });
		taRegisterTool('fontColor', {
		                buttontext: "<i class='fa fa-font' style='color:red''></i>",
        		        action: function(){
        		            this.$editor().wrapSelection('forecolor', 'red');
        		        }
        });
        return taOptions;
	}]);
});
