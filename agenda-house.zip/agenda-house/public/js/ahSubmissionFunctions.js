// AngularJS controller
var app = angular.module('submissionApp', ['ngSanitize']);
app.controller('submissionCtrl', function ($scope, $rootScope, $http) {
    $scope.title = "";
    $scope.reportText = "";
    $scope.output = "";
    $scope.showBtn = {"display": "none"};
    $scope.accepted = false;

    $scope.acceptCheck = function() {
        if ($scope.accepted) {
            $scope.accepted = false;
            $scope.showBtn = {'display': "none"};
        } else {
            $scope.accepted = true;
            $scope.showBtn = {'display': "initial"};
        }
    };

    function showTerms(){
        $.getJSON('js/termsConditions.json' , function(data){
            $scope.termsConditions = data.terms;
            return false;
            //return false;
        });
    };
    showTerms();

   // check given input box not empty - used to check for title and text
    function emptyCheck(x) {
        result = (typeof x == undefined || x.length == 0) ? "null" : x;
        return result;
    }
	
	function createNewContribution(){
		var newContribution = [];
		var contStr = 
		newContribution.push({"contentId":null, "contentType":"CONTRIBUTION","title":$scope.title,"creatorId":102,"originator":"Karen Testing","creationTimestamp":Math.floor(Date.now()),"shares":null,"country":"UK","status":"SUBMITTED","serialId":null,"reportText":$scope.reportText,"imageId":null,"videoId":null,"audioId":null});
		console.log("Setting up a blank contribution", newContribution[0]);
		return newContribution[0];
	}	


    // Submit form function
    $scope.submitForm = function() {
        // Checks whether the title or text contains anything.
        console.log("in submit form", emptyCheck($scope.title), emptyCheck($scope.reportText));
        if (emptyCheck($scope.title) == "null" || emptyCheck($scope.reportText) == "null"){
            // If so, will make the necessary empty box red.
            if (emptyCheck($scope.title) == "null") {
                console.log("no title");
                $scope.titleCheck = {"border": "2px red solid"};
            } else {
                $scope.titleCheck = {};
            }
            if (emptyCheck($scope.reportText) == "null") {
                $scope.textCheck = {"border": "2px red solid"};
            } else {
                $scope.textCheck = {};
            }
        } else {
			console.log("submitting the contribution");
            $scope.titleCheck = {};
            $scope.textCheck = {};
			console.log("Saving contribution: ", $scope.newContribution);
			$scope.newContribution = createNewContribution();
			$http({
					url: "/contribution",
					method: "POST",
					data: $scope.newContribution
			}).success(function (data, status, headers, config) {
					console.log("Saving message: ", data);
					$("#contributionReceipt").css('display','block');
			}).error(function (data, status, headers, config) {
					console.log("Error - message not saved.  Error code: ", status);
			});			
        }
    };
	
	$scope.showImageChooser = function(){
		console.log("showing modal");
		$('#imageUploadModal').css('display','block');
	}
	

	$scope.uploadImage = function(filename){
        console.log("uploading image");
		
    }
});