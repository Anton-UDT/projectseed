var app = angular.module('textApp', ['textAngular'])


app.config(['$provide', function($provide){
		// register a new tool and add it to the default toolbar
		$provide.decorator('taOptions', ['taRegisterTool', 'taSelection', 'taBrowserTag', 'taTranslations',
                                             'taToolFunctions', '$delegate',
                                             function(taRegisterTool, taSelection, taBrowserTag, taTranslations,
                                                      taToolFunctions, taOptions){
			// $delegate is the taOptions we are decorating
			// here we override the default toolbars and classes specified in taOptions.
			taOptions.forceTextAngularSanitize = true; // set false to allow the textAngular-sanitize provider to be replaced
			taOptions.keyMappings = []; // allow customizable keyMappings for specialized key boards or languages
			taOptions.toolbar = [['fontShrink', 'fontDefault', 'fontGrow'],['bold', 'italics', 'insertLink']];
			taOptions.classes = {
				focussed: 'focussed',
				toolbar: 'btn-toolbar',
				toolbarGroup: 'btn-group',
				toolbarButton: 'btn btn-default',
				toolbarButtonActive: 'active',
				disabled: 'disabled',
				textEditor: 'form-control',
				htmlEditor: 'form-control'
			};
			return taOptions; // taOptions are provided to the decorator which can format the styling of those options
		}])
	}]);


app.config(function($provide){
	$provide.decorator('taOptions', ['taRegisterTool', '$delegate', function(taRegisterTool, taOptions){
		// $delegate is the taOptions we are decorating
		// register the tool with textAngular
		taRegisterTool('fontGrow', {
        		        display: "<i class='material-icons' style='font-size: 22px'>format_size</i>",
        		        //buttontext: "<i class=" + 'material-icons' + ">" + "format_size" + "</i>",
        		        action: function(){
        		        this.$editor().wrapSelection('fontSize', '5em');
        		         }
        		 });
		taRegisterTool('fontDefault', {
		                display: "<i class='material-icons' style='font-size: 22px'>title</i>",
        		        //buttontext: "<i class=" + 'material-icons' + ">" + "title" + "</i>",
        		        action: function(){
        		            this.$editor().wrapSelection('fontSize', '3em');
        		        }
        		 });
		taRegisterTool('fontColorRed', {
                		display: "<i class='material-icons' style='font-weight: bold; font-size: 22px;color: red'>A</i>'",
                		action: function(){
                		    this.$editor().wrapSelection('forecolor', 'red');
                		}
        });
        taRegisterTool('fontColorBlue', {
                        display: "<i class='material-icons' style='font-weight: bold; font-size: 22px;color: blue'>A</i>'",
                        action: function(){
                        this.$editor().wrapSelection('forecolor', 'blue');
                        }
        });
        taRegisterTool('fontColorGreen', {
                         display: "<i class='material-icons' style='font-weight: bold; font-size: 22px;color: green'>A</i>'",
                         //buttontext: "<i class=" + 'material-icons fontGreen' + ">" + "G" + "</i>",
                         action: function(){
                            this.$editor().wrapSelection('forecolor', 'green');
                         }
        });
        taRegisterTool('fontColorBlack', {
                         display: "<i class='material-icons' style='font-weight: bold; font-size: 22px;color: black'>A</i>'",
                        // buttontext: "<i class=" + 'material-icons fontNormal' + ">" + "A" + "</i>",
                         action: function(){
                             this.$editor().wrapSelection('forecolor', 'black');
                          }
        });
        return taOptions;
	}]);
});

app.controller("textEditCtrl", function($scope) {
	//controlling text editor configuration
});

