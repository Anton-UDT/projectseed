var app = angular.module("myApp", []);

//header controller for later
app.controller("wHeaderCtrl", function($scope,$http){
});

//video controller for later
app.controller("wVideoCtrl", function($scope,$http){
});

//controller for message page
app.controller("wMessageCtrl", function ($scope, $http) {

    function getMessage() {
        console.log("Retrieving message");
		$http({
             url: "/message/country/UK",
             method: "GET"
		}).success(function (data, status, headers, config) {
				$scope.currMessage = data.messageText ;
				$scope.messageHeading = data.title;
				console.log("Message text: ", data.messageText);
				return false;
		}).error(function (data, status, headers, config) {
            	$scope.currMessage = "No message set";
            	$scope.messageHeading = "Message Board";
            	return false;
		});
    };
    getMessage();
});

//controller for story display
app.controller("wStoryCtrl", function ($scope, $filter, $http) {

    // Act upon a headline box being clicked
    $scope.headlineClicked = function (n) {
        console.log("article ", n, " clicked");
        //showStoryPage(n);
    };
	

    // Get an array of stories in JSON format retrieved from the database
    function getStories() {
        console.log("getting latest stories");
		$http({
             url: "/stories",
             method: "GET"
		}).success(function (data, status, headers, config) {
				console.log("data stories: ", data);
				$scope.stories = data;
				console.log("featuredStory: ", $scope.stories[0])
				$scope.featuredStory = $scope.stories[0];
				$scope.currFeaturedStory = 0;
		}).error(function (data, status, headers, config) {
            	$scope.message = "No current stories";
				console.log("Error", status);
		});
        return(false);
    };

    // run getStories() on load
    getStories();
	
	//format timestamps to day, month, day number, year
	$scope.toDate = function(timestamp){
		return $filter('date')(timestamp, 'fullDate');
	}

    // Open a new story template page with selected story
    //showStoryPage(serialId);
});


/*
//code for video file upload convert to Angular and add to contribution controller.
            $(document).ready( function() {
                $("#imageUpload:file").change(function (){
                    if ($('#imageUpload').get(0).files.length === 0) {
                        $(".imageUp").removeClass("btn-outline-primary").addClass("btn-outline-secondary");
                    } else {
                        $(".imageUp").removeClass("btn-outline-secondary").addClass("btn-outline-primary");
                    }
                });

                $("#videoUpload:file").change(function (){
                    if ($('#videoUpload').get(0).files.length === 0) {
                        $(".videoUp").removeClass("btn-outline-primary").addClass("btn-outline-secondary");
                    } else {
                        $(".videoUp").removeClass("btn-outline-secondary").addClass("btn-outline-primary");
                    }
                });

                $("#audioUpload:file").change(function (){
                    if ($('#audioUpload').get(0).files.length === 0) {
                        $(".audioUp").removeClass("btn-outline-primary").addClass("btn-outline-secondary");
                    } else {
                        $(".audioUp").removeClass("btn-outline-secondary").addClass("btn-outline-primary");
                    }
                });
            });

            function getSelected() {
                var selected = "";
                if (typeof window.getSelection != "undefined") {
                    var sel = window.getSelection();
                    if (sel.rangeCount) {
                        var container = document.createElement("div");
                        for (var i = 0, len = sel.rangeCount; i < len; ++i) {
                            container.appendChild(sel.getRangeAt(i).cloneContents());
                        }
                        selected = container.innerHTML;
                    }
                } else if (typeof document.selection != "undefined") {
                    if (document.selection.type == "Text") {
                        selected = document.selection.createRange().htmlText;
                    }
                }
                return selected;
            }

            // Function for checking content of title and text.
            function emptyCheck(x) {
                result = (typeof x == undefined || x.length == 0) ? "null" : x;
                return result;
            }

            // Function for checking whether a file (image, video or audio) has been uploaded.
            function nullCheck(x){
                var y = x.value.split(/(\\|\/)/g).pop();
                result = (y.length != 0) ? y : null;
                return result;
            }

            function escapeHTML(html) {
                return html.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
            }

            // Using the button, click hidden input filers
            function uploadDoc(x) {
                document.getElementById(x).click();
            }

            function getExtension(x) {
                var parts = x.split('.');
                return parts[parts.length - 1];
            }

            function isImage(x) {
                var ext = getExtension(x);
                switch (ext.toLowerCase()) {
                case 'jpg':
                case 'gif':
                case 'bmp':
                case 'png':
                    return true;
                }
                return false;
            }

            function isVideo(x) {
                var ext = getExtension(x);
                switch (ext.toLowerCase()) {
                case 'm4v':
                case 'avi':
                case 'mpg':
                case 'mp4':
                    return true;
                }
                return false;
            }

            function isAudio(x) {
                var ext = getExtension(x);
                switch (ext.toLowerCase()) {
                case 'wav':
                case 'mp3':
                case 'aiff':
                case 'ogg':
                case 'gsm':
                case 'dct':
                case 'flac':
                case 'au':
                case 'vox':
                case 'raw':
                    return true;
                }
                return false;
            }



            function fileCheck(x, format) {
                var checked = nullCheck(x);
                var t = (checked === null) ? "null" : checked;

                if (t != "null") {
                    var size = x.files[0].size;
                    if (format == "image") {
                        if (isImage(checked)) {
                            if (size >= 10000000) {
                                alert("Image uploaded is too big, upload failed!");
                                return false;
                            } else {
                                return true;
                            }
                        } else {
                            alert("File uploaded to image is not an image!");
                            return false;
                        }
                    } else if (format == "video") {
                        if (isVideo(checked)) {
                            if (size >= 10000000000) {
                                alert("Video uploaded is too big, upload failed!");
                                return false;
                            } else {
                                return true;
                            }
                        } else {
                            alert("File uploaded to video is not a video!");
                            return false;
                        }
                    } else {
                        if (isAudio(checked)) {
                            if (size >= 10000000000) {
                                alert("Audio uploaded is too big, upload failed!");
                                return false;
                            } else {
                                return true;
                            }
                        } else {
                            alert("File uploaded to audio is not an audio!");
                            return false;
                        }
                    }
                } else {
                    return "No file";
                }
            }

*/